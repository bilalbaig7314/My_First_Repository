import React, { useState, useEffect } from "react";
import { View, Text, TextInput, Button, FlatList, Image, TouchableOpacity, StyleSheet, Alert, ScrollView } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function App() {
    const [query, setQuery] = useState("");
    const [products, setProducts] = useState([]);
    const [allProducts, setAllProducts] = useState([]);
    const [cart, setCart] = useState([]);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [checkout, setCheckout] = useState(false);

    useEffect(() => {
        fetchProducts();
        loadCart();
    }, []);

    // Fetch products from backend
    const fetchProducts = async () => {
        try {
            const response = await fetch("http://192.168.100.144:5000/api/products"); // Replace with your backend IP
            const data = await response.json();
            setProducts(data);
            setAllProducts(data);
        } catch (error) {
            console.error("❌ Error fetching products:", error);
            alert("Failed to fetch products.");
        }
    };

    // Load cart from AsyncStorage
    const loadCart = async () => {
        try {
            const storedCart = await AsyncStorage.getItem("cart");
            if (storedCart) {
                setCart(JSON.parse(storedCart));
            }
        } catch (error) {
            console.error("❌ Error loading cart:", error);
        }
    };

    // Save cart to AsyncStorage
    const saveCart = async (updatedCart) => {
        try {
            await AsyncStorage.setItem("cart", JSON.stringify(updatedCart));
        } catch (error) {
            console.error("❌ Error saving cart:", error);
        }
    };

    const handleSearch = () => {
        if (!query.trim()) {
            setProducts(allProducts);
            return;
        }
        const filtered = allProducts.filter((product) =>
            product.title.toLowerCase().includes(query.toLowerCase())
        );
        setProducts(filtered);
    };

    const addToCart = (item) => {
        const updatedCart = [...cart, item];
        setCart(updatedCart);
        saveCart(updatedCart);
        Alert.alert("Added to Cart", `${item.title} has been added!`);
    };

    const getTotalPrice = () => {
        return cart.reduce((total, item) => total + item.price, 0).toFixed(2);
    };

    const handleCheckout = () => {
        setCheckout(true);
    };

    const confirmPayment = () => {
        Alert.alert("✅ Payment Successful", `Total Paid: $${getTotalPrice()}`);
        setCart([]);
        saveCart([]);
        setCheckout(false);
    };

    const showProductDetails = (product) => {
        setSelectedProduct(product);
    };

    return (
        <View style={styles.container}>
            {!selectedProduct && !checkout ? (
                <>
                    <Text style={styles.title}>🛒 E-Commerce App</Text>

                    <TextInput
                        style={styles.input}
                        placeholder="Search for products..."
                        value={query}
                        onChangeText={setQuery}
                    />
                    <Button title="Search" onPress={handleSearch} />

                    <FlatList
                        data={products}
                        keyExtractor={(item) => item.id.toString()}
                        renderItem={({ item }) => (
                            <TouchableOpacity onPress={() => showProductDetails(item)}>
                                <View style={styles.card}>
                                    <Image source={{ uri: item.image }} style={styles.image} />
                                    <Text style={styles.name}>{item.title}</Text>
                                    <Text style={styles.price}>${item.price}</Text>
                                    <TouchableOpacity style={styles.addButton} onPress={() => addToCart(item)}>
                                        <Text style={styles.addButtonText}>Add to Cart</Text>
                                    </TouchableOpacity>
                                </View>
                            </TouchableOpacity>
                        )}
                    />

                    {/* Cart Section */}
                    <View style={styles.cartContainer}>
                        <Text style={styles.cartTitle}>🛍️ Cart: {cart.length} items</Text>
                        <Text style={styles.total}>Total: ${getTotalPrice()}</Text>
                        <Button title="Proceed to Checkout" onPress={handleCheckout} color="green" />
                    </View>
                </>
            ) : checkout ? (
                // Checkout Screen
                <View style={styles.checkoutContainer}>
                    <Text style={styles.cartTitle}>💳 Payment Checkout</Text>
                    <Text style={styles.total}>Total: ${getTotalPrice()}</Text>
                    <Button title="Confirm Payment" onPress={confirmPayment} color="blue" />
                    <Button title="Cancel" onPress={() => setCheckout(false)} color="red" />
                </View>
            ) : (
                // Product Details Screen
                <ScrollView style={styles.detailsContainer}>
                    <Image source={{ uri: selectedProduct.image }} style={styles.detailImage} />
                    <Text style={styles.detailTitle}>{selectedProduct.title}</Text>
                    <Text style={styles.detailPrice}>${selectedProduct.price}</Text>
                    <Text style={styles.detailDescription}>{selectedProduct.description || "No description available."}</Text>
                    <Button title="Add to Cart" onPress={() => addToCart(selectedProduct)} />
                    <Button title="Go Back" onPress={() => setSelectedProduct(null)} color="red" />
                </ScrollView>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, padding: 20, backgroundColor: "#f5f5f5" },
    title: { fontSize: 24, fontWeight: "bold", textAlign: "center", marginBottom: 20 },
    input: { borderWidth: 1, padding: 10, marginBottom: 10, borderRadius: 5, backgroundColor: "white" },
    card: { backgroundColor: "white", padding: 15, marginVertical: 10, borderRadius: 10, alignItems: "center" },
    image: { width: 150, height: 150, resizeMode: "contain" },
    name: { fontSize: 16, fontWeight: "bold", marginTop: 10, textAlign: "center" },
    price: { fontSize: 14, color: "green", marginTop: 5 },
    addButton: { backgroundColor: "#007bff", padding: 10, marginTop: 10, borderRadius: 5 },
    addButtonText: { color: "white", fontWeight: "bold" },
    cartContainer: { padding: 15, backgroundColor: "white", borderRadius: 10, marginTop: 20 },
    cartTitle: { fontSize: 18, fontWeight: "bold", textAlign: "center" },
    total: { fontSize: 16, fontWeight: "bold", textAlign: "center", color: "green", marginTop: 5 },
    checkoutContainer: { flex: 1, justifyContent: "center", alignItems: "center" },
    detailsContainer: { padding: 20 },
    detailImage: { width: "100%", height: 300, resizeMode: "contain" },
    detailTitle: { fontSize: 22, fontWeight: "bold", textAlign: "center", marginTop: 10 },
    detailPrice: { fontSize: 18, color: "green", textAlign: "center", marginTop: 5 },
    detailDescription: { fontSize: 14, textAlign: "center", marginTop: 10, paddingHorizontal: 10 }
});
